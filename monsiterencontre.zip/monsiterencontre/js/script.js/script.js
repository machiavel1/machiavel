const form = document.getElementById("registerForm");
const message = document.getElementById("message");

form.addEventListener("submit", async (e) => {
  e.preventDefault(); // Empêche l'envoi du formulaire par défaut

  const nom = form.nom.value;
  const email = form.email.value;
  const password = form.password.value;

  try {
    // Cette URL est un exemple. Ton backend réel sera différent.
    // Pour le moment, cette partie du code n'interagira pas réellement avec un serveur.
    const response = await fetch("https://ton-backend.repl.co/api/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ nom, email, password }),
    });

    const result = await response.json();

    if (response.ok) {
      message.textContent = result.message || "Inscription réussie !";
      message.style.color = "lightgreen";
      form.reset(); // Vide le formulaire après succès
    } else {
      message.textContent = result.error || "Erreur lors de l'inscription.";
      message.style.color = "red";
    }
  } catch (error) {
    console.error("Erreur de connexion au backend :", error);
    message.textContent = "Erreur de connexion au serveur. Veuillez réessayer.";
    message.style.color = "red";
  }
});
